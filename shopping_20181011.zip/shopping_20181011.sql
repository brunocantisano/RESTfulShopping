-- --------------------------------------------------------
-- Servidor:                     192.168.0.60
-- Versão do servidor:           Microsoft SQL Server 2017 (RTM-CU11) (KB4462262) - 14.0.3038.14
-- OS do Servidor:               Linux (Ubuntu 16.04.5 LTS)
-- HeidiSQL Versão:              9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES  */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Copiando estrutura do banco de dados para shopping
CREATE DATABASE IF NOT EXISTS "shopping";
USE "shopping";

-- Copiando estrutura para tabela shopping.loja
CREATE TABLE IF NOT EXISTS "loja" (
	"cnpj" NUMERIC(14,0) NOT NULL,
	"nome" VARCHAR(50) NOT NULL,
	"piso" INT(10,0) NOT NULL,
	"numero" INT(10,0) NOT NULL,
	"dataSaida" DATE(0) NULL DEFAULT (NULL),
	"segmentos" VARCHAR(255) NOT NULL,
	PRIMARY KEY ("cnpj")
);

-- Copiando dados para a tabela shopping.loja: -1 rows
/*!40000 ALTER TABLE "loja" DISABLE KEYS */;
/*!40000 ALTER TABLE "loja" ENABLE KEYS */;

-- Copiando estrutura para tabela shopping.usuario
CREATE TABLE IF NOT EXISTS "usuario" (
	"id" INT(10,0) NOT NULL,
	"nome" VARCHAR(10) NOT NULL,
	"senha" VARCHAR(10) NOT NULL,
	PRIMARY KEY ("id")
);

-- Copiando dados para a tabela shopping.usuario: -1 rows
/*!40000 ALTER TABLE "usuario" DISABLE KEYS */;
INSERT INTO "usuario" ("id", "nome", "senha") VALUES
	(1, 'usuario', 'senha');
/*!40000 ALTER TABLE "usuario" ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
